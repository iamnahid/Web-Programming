--
-- Database: `stugeek`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` varchar(255) NOT NULL,
  `correct` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `performers`
--

CREATE TABLE `performers` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `percentage` varchar(24) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(10) NOT NULL,
  `ques` text NOT NULL,
  `option_one` varchar(40) NOT NULL,
  `option_two` varchar(40) NOT NULL,
  `answer` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `ques`, `option_one`, `option_two`, `answer`) VALUES
(1, 'Your name is monalisa..', 'True', 'False', 'True'),
(2, 'Your name is nahida..', 'True', 'False', 'False'),
(3, 'HTML client side language', 'True', 'False', 'True'),
(4, 'Ajax is advance javascript and xml', 'True', 'False', 'True'),
(5, 'Ajax is advance javascript.', 'True', 'False', 'False'),
(6, 'PHP= Hypertext Preprocessor', 'True', 'False', 'True'),
(7, 'Are you a human?', 'True', 'False', 'False'),
(8, 'Am i AWESOME?', 'True', 'False', 'True'),
(9, 'HTML & PHP are same?', 'True', 'False', 'False'),
(10, 'Server side language is php', 'True', 'False', 'True');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Pass` varchar(20) NOT NULL,
  `Uname` varchar(20) NOT NULL,
  `Rank` int(100) NOT NULL,
  `Score` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`FName`, `LName`, `Email`, `Pass`, `Uname`, `Rank`, `Score`) VALUES
('a', 'bc', 'abc', '000', 'abc0', 100, 10),
('Arafat', 'Sani', 'araf@gmail.com', 'iamarasani', 'arasani123', 0, 0),
('ashraf', 'Misbah', 'amis@yh.com', 'qwerty123', 'ashrafm123', 0, 0),
('fsd', 'sdfsd', 'sdfs', 'sd', 'dfs', 0, 0),
('Nahidul', 'Islam', 'nrk', '123', 'iamnahid', 1, 100000),
('Rianna', 'Islam', 'r9@com', 'r123', 'iamr5', 0, 0),
('sharukh', 'khan', 'srk@some.com', 'iamsrk', 'iamsrk', 0, 0),
('jhfgjhghg', 'hgjhvvmvmvmn', 'bvbnvb@ghf.com', '1234567890', 'jhfjhf', 0, 0),
('ghbhkbbk', 'hghvnmv', 'ghcghcgc@y.com', '12345678', 'jhfjhvhvhvk', 0, 0),
('Najid', 'Islam', 'najid@aiub.edu', 'najid', 'najid', 0, 0),
('nazim', 'uddin', 'nazim@aiub.edu', 'nazim123', 'nazim@', 0, 0),
('Pinky', 'chowdhury', 'pny@yahoo.com', 'iampny', 'pinky@', 0, 0),
('Samiul', 'Newaz', 'sn@yahoo.com', 'samiulNewaz!123', 'samiul3012', 0, 0),
('Shahnama', 'Monalisa', 'slisa', '456', 'smonalisa', 2, 10000),
('tasnim', 'farzana', 'tasnim@something.com', 'tasnim', 'tasnim_far', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sysuser`
--

CREATE TABLE `sysuser` (
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Pass` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Uname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sysuser`
--

INSERT INTO `sysuser` (`FName`, `LName`, `Email`, `Pass`, `Type`, `Uname`) VALUES
('a', 'b', 'c', 'abc', 'admin', 'abc'),
('a', 'bc', 'abc@', '000', 'admin', 'abc0'),
('Nahidul', 'Islam', 'nrk', '123', 'admin', 'iamn9'),
('nazim', 'uddin', 'nazim@aiub.edu', 'nazim123', 'Admin', 'nazim@'),
('Shahnama', 'Monalisa', 'slisa', '456', 'Admin', 'smonalisa'),
('tasnim', 'farzana', 'tasnim@something.com', 'tasnim', 'Admin', 'tasnim_far');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `performers`
--
ALTER TABLE `performers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD UNIQUE KEY `Uname` (`Uname`);

--
-- Indexes for table `sysuser`
--
ALTER TABLE `sysuser`
  ADD UNIQUE KEY `Uname` (`Uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `performers`
--
ALTER TABLE `performers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
